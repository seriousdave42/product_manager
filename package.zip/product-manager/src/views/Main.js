import React from 'react';
import ProdForm from '../components/ProdForm';

const Main = () => {
    return(
        <div>
            <ProdForm />
        </div>
    )
}

export default Main;