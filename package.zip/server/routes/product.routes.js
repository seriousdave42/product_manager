const ProductController = require("../controllers/product.controllers");

module.exports = app => {
  app.get("/api/products/", ProductController.index);
//   app.get("/api/product/random", ProductController.findRandomJoke);
//   app.get("/api/product/:id", ProductController.findOneSingleJoke);
//   app.put("/api/product/update/:id", ProductController.updateExistingJoke);
  app.post("/api/product/create", ProductController.createProduct);
//   app.delete("/api/jokes/delete/:id", ProductController.deleteAnExistingJoke);
};